import './globals.css';
import type { Metadata } from 'next';
import { Inter } from 'next/font/google';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'Dr. Serena Blake, PsyD - Clinical Psychologist in Los Angeles',
  description: 'Licensed clinical psychologist offering compassionate, evidence-based therapy for anxiety, relationships, and trauma recovery in Los Angeles, CA. Virtual and in-person sessions available.',
  keywords: 'therapist, psychologist, therapy, anxiety, trauma, relationships, Los Angeles, clinical psychology',
  openGraph: {
    title: 'Dr. Serena Blake, PsyD - Clinical Psychologist',
    description: 'Compassionate, evidence-based therapy for anxiety, relationships, and trauma recovery in Los Angeles, CA.',
    type: 'website',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className={inter.className}>{children}</body>
    </html>
  );
}