"use client";

import { useState } from 'react';
import { Phone, Mail, MapPin, Clock, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

export default function Home() {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    message: '',
    preferredTime: '',
    agreeToContact: false
  });
  
  const [errors, setErrors] = useState({});
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const handleCheckboxChange = (checked) => {
    setFormData(prev => ({
      ...prev,
      agreeToContact: checked
    }));
    if (errors.agreeToContact) {
      setErrors(prev => ({
        ...prev,
        agreeToContact: ''
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.name.trim()) {
      newErrors.name = 'Name is required';
    }
    
    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone number is required';
    }
    
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email';
    }
    
    if (!formData.message.trim()) {
      newErrors.message = 'Please tell us what brings you here';
    }
    
    if (!formData.preferredTime.trim()) {
      newErrors.preferredTime = 'Preferred time is required';
    }
    
    if (!formData.agreeToContact) {
      newErrors.agreeToContact = 'Please agree to be contacted';
    }
    
    return newErrors;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const newErrors = validateForm();
    
    if (Object.keys(newErrors).length === 0) {
      setIsSubmitted(true);
      // Here you would typically send the data to your backend
      console.log('Form submitted:', formData);
    } else {
      setErrors(newErrors);
    }
  };

  return (
    <main className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center bg-gradient-to-br from-slate-600 to-slate-800 overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: 'url("https://images.pexels.com/photos/1001682/pexels-photo-1001682.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop")',
          }}
        >
          <div className="absolute inset-0 bg-slate-800/40"></div>
        </div>
        
        <div className="relative z-10 text-center px-4 max-w-4xl">
          <h1 className="text-4xl md:text-6xl font-serif text-white mb-6 leading-tight">
            Psychological Care for<br />
            <span className="text-sage-100">Change, Insight, and Well-Being</span>
          </h1>
          <h2 className="text-lg md:text-xl text-sage-100 mb-8 font-light max-w-3xl mx-auto">
            Offering compassionate, evidence-based therapy to help you overcome anxiety, 
            strengthen relationships, and heal from trauma in Los Angeles, CA
          </h2>
          <Button 
            size="lg" 
            className="bg-sage-600 hover:bg-sage-700 text-white px-8 py-3 rounded-full text-lg font-medium transition-all duration-300 shadow-lg"
            onClick={() => document.getElementById('contact').scrollIntoView({ behavior: 'smooth' })}
          >
            Book a Free Consultation
          </Button>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-sage-50">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-serif text-slate-800 mb-6">
                About Dr. Serena Blake
              </h2>
              <div className="space-y-4 text-slate-600 leading-relaxed">
                <p>
                  Dr. Serena Blake is a licensed clinical psychologist (PsyD) based in Los Angeles, CA, 
                  with eight years of experience and over 500 client sessions. She blends evidence-based 
                  approaches—like cognitive-behavioral therapy and mindfulness—with compassionate, 
                  personalized care to help you overcome anxiety, strengthen relationships, and heal from trauma.
                </p>
                <p>
                  Whether you meet in her Maplewood Drive office or connect virtually via Zoom, 
                  Dr. Blake is committed to creating a safe, supportive space for you to thrive.
                </p>
              </div>
              
              <div className="mt-8 space-y-3">
                <div className="flex items-center text-slate-600">
                  <MapPin className="w-5 h-5 mr-3 text-sage-600" />
                  <span>1287 Maplewood Drive, Los Angeles, CA 90026</span>
                </div>
                <div className="flex items-center text-slate-600">
                  <Phone className="w-5 h-5 mr-3 text-sage-600" />
                  <span>(323) 555-0192</span>
                </div>
                <div className="flex items-center text-slate-600">
                  <Mail className="w-5 h-5 mr-3 text-sage-600" />
                  <span>serena@blakepsychology.com</span>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <div className="relative overflow-hidden rounded-2xl bg-sage-200 aspect-square">
                <img
                  src="https://images.pexels.com/photos/3717378/pexels-photo-3717378.jpeg?auto=compress&cs=tinysrgb&w=600&h=600&fit=crop"
                  alt="Dr. Serena Blake"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-serif text-slate-800 mb-4">
              How I Help
            </h2>
            <p className="text-slate-600 text-lg max-w-2xl mx-auto">
              Specialized therapeutic services tailored to your unique needs and goals
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {/* Anxiety & Stress Management */}
            <div className="bg-sage-50 rounded-2xl p-8 border border-sage-100">
              <div className="mb-6">
                <img
                  src="https://images.pexels.com/photos/3762543/pexels-photo-3762543.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop"
                  alt="Anxiety and Stress Management"
                  className="w-full h-48 object-cover rounded-lg"
                />
              </div>
              <h3 className="text-xl font-serif text-slate-800 mb-4">
                Anxiety & Stress Management
              </h3>
              <p className="text-slate-600 leading-relaxed">
                Learn practical strategies to manage overwhelming feelings and develop healthy coping mechanisms. 
                Through evidence-based techniques including mindfulness and cognitive-behavioral approaches, 
                we'll work together to reduce anxiety and build resilience for life's challenges.
              </p>
            </div>

            {/* Relationship Counseling */}
            <div className="bg-sage-50 rounded-2xl p-8 border border-sage-100">
              <div className="mb-6">
                <img
                  src="https://images.pexels.com/photos/1024311/pexels-photo-1024311.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop"
                  alt="Relationship Counseling"
                  className="w-full h-48 object-cover rounded-lg"
                />
              </div>
              <h3 className="text-xl font-serif text-slate-800 mb-4">
                Relationship Counseling
              </h3>
              <p className="text-slate-600 leading-relaxed">
                Strengthen your connections with partners, family, and friends through improved communication 
                and conflict resolution skills. Whether you're navigating relationship challenges or seeking 
                to deepen intimacy, I provide a safe space to explore and heal together.
              </p>
            </div>

            {/* Trauma Recovery */}
            <div className="bg-sage-50 rounded-2xl p-8 border border-sage-100">
              <div className="mb-6">
                <img
                  src="https://images.pexels.com/photos/3771788/pexels-photo-3771788.jpeg?auto=compress&cs=tinysrgb&w=400&h=300&fit=crop"
                  alt="Trauma Recovery"
                  className="w-full h-48 object-cover rounded-lg"
                />
              </div>
              <h3 className="text-xl font-serif text-slate-800 mb-4">
                Trauma Recovery
              </h3>
              <p className="text-slate-600 leading-relaxed">
                Heal from past experiences with compassionate, trauma-informed care that honors your 
                unique journey. Using specialized therapeutic approaches, we'll work at your pace to 
                process difficult experiences and reclaim your sense of safety and empowerment.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Office Hours & Fees */}
      <section className="py-20 bg-sage-50">
        <div className="max-w-4xl mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl font-serif text-slate-800 mb-6">Office Hours</h3>
              <div className="space-y-4">
                <div className="flex items-start">
                  <Clock className="w-5 h-5 mr-3 text-sage-600 mt-1" />
                  <div>
                    <p className="font-medium text-slate-800">In-Person Sessions</p>
                    <p className="text-slate-600">Tuesday & Thursday, 10 AM–6 PM</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <Clock className="w-5 h-5 mr-3 text-sage-600 mt-1" />
                  <div>
                    <p className="font-medium text-slate-800">Virtual Sessions (Zoom)</p>
                    <p className="text-slate-600">Monday, Wednesday & Friday, 1 PM–5 PM</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="text-2xl font-serif text-slate-800 mb-6">Session Fees</h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center py-2 border-b border-sage-200">
                  <span className="text-slate-800">Individual Session</span>
                  <span className="font-medium text-slate-800">$200</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-sage-200">
                  <span className="text-slate-800">Couples Session</span>
                  <span className="font-medium text-slate-800">$240</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-serif text-slate-800 mb-4">
              Frequently Asked Questions
            </h2>
            <p className="text-slate-600 text-lg">
              Common questions about therapy sessions and my practice
            </p>
          </div>
          
          <Accordion type="single" collapsible className="space-y-4">
            <AccordionItem value="insurance" className="border border-sage-200 rounded-lg px-6">
              <AccordionTrigger className="text-left font-medium text-slate-800 hover:no-underline">
                Do you accept insurance?
              </AccordionTrigger>
              <AccordionContent className="text-slate-600 pb-4">
                I do not accept insurance directly, but I provide a superbill for self-submission to your insurance provider. 
                Many clients find they can receive partial reimbursement through their out-of-network benefits.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="online" className="border border-sage-200 rounded-lg px-6">
              <AccordionTrigger className="text-left font-medium text-slate-800 hover:no-underline">
                Are online sessions available?
              </AccordionTrigger>
              <AccordionContent className="text-slate-600 pb-4">
                Yes, I offer virtual sessions via Zoom on Mondays, Wednesdays, and Fridays from 1 PM to 5 PM. 
                Online therapy can be just as effective as in-person sessions and provides greater flexibility for your schedule.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="cancellation" className="border border-sage-200 rounded-lg px-6">
              <AccordionTrigger className="text-left font-medium text-slate-800 hover:no-underline">
                What is your cancellation policy?
              </AccordionTrigger>
              <AccordionContent className="text-slate-600 pb-4">
                I require 24-hour notice for cancellations. This allows me to offer the time slot to other clients who may need it. 
                Cancellations made with less than 24 hours notice may be subject to a cancellation fee.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-sage-50">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-serif text-slate-800 mb-4">
              Get Started Today
            </h2>
            <p className="text-slate-600 text-lg">
              Ready to begin your journey? Fill out the form below and I'll get back to you within 24 hours.
            </p>
          </div>
          
          {isSubmitted ? (
            <div className="bg-white rounded-2xl p-8 text-center border border-sage-200">
              <CheckCircle className="w-16 h-16 text-sage-600 mx-auto mb-4" />
              <h3 className="text-2xl font-serif text-slate-800 mb-4">Thank You!</h3>
              <p className="text-slate-600 mb-6">
                I've received your message and will get back to you within 24 hours. 
                I look forward to supporting you on your journey.
              </p>
              <Button 
                onClick={() => {
                  setIsSubmitted(false);
                  setFormData({
                    name: '',
                    phone: '',
                    email: '',
                    message: '',
                    preferredTime: '',
                    agreeToContact: false
                  });
                }}
                className="bg-sage-600 hover:bg-sage-700"
              >
                Send Another Message
              </Button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="bg-white rounded-2xl p-8 border border-sage-200">
              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Full Name *
                  </label>
                  <Input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    className={`${errors.name ? 'border-red-500' : 'border-sage-200'}`}
                    placeholder="Enter your full name"
                  />
                  {errors.name && (
                    <p className="text-red-500 text-sm mt-1">{errors.name}</p>
                  )}
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Phone Number *
                  </label>
                  <Input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    className={`${errors.phone ? 'border-red-500' : 'border-sage-200'}`}
                    placeholder="(555) 123-4567"
                  />
                  {errors.phone && (
                    <p className="text-red-500 text-sm mt-1">{errors.phone}</p>
                  )}
                </div>
              </div>
              
              <div className="grid md:grid-cols-2 gap-6 mb-6">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Email Address *
                  </label>
                  <Input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className={`${errors.email ? 'border-red-500' : 'border-sage-200'}`}
                    placeholder="your@email.com"
                  />
                  {errors.email && (
                    <p className="text-red-500 text-sm mt-1">{errors.email}</p>
                  )}
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    Preferred Time to Reach You *
                  </label>
                  <Input
                    type="text"
                    name="preferredTime"
                    value={formData.preferredTime}
                    onChange={handleInputChange}
                    className={`${errors.preferredTime ? 'border-red-500' : 'border-sage-200'}`}
                    placeholder="e.g., Weekday mornings"
                  />
                  {errors.preferredTime && (
                    <p className="text-red-500 text-sm mt-1">{errors.preferredTime}</p>
                  )}
                </div>
              </div>
              
              <div className="mb-6">
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  What brings you here? *
                </label>
                <Textarea
                  name="message"
                  value={formData.message}
                  onChange={handleInputChange}
                  className={`${errors.message ? 'border-red-500' : 'border-sage-200'} min-h-[120px]`}
                  placeholder="Tell me a bit about what you're looking for in therapy..."
                />
                {errors.message && (
                  <p className="text-red-500 text-sm mt-1">{errors.message}</p>
                )}
              </div>
              
              <div className="mb-8">
                <div className="flex items-start space-x-3">
                  <Checkbox
                    id="agreeToContact"
                    checked={formData.agreeToContact}
                    onCheckedChange={handleCheckboxChange}
                    className="mt-1"
                  />
                  <label 
                    htmlFor="agreeToContact" 
                    className="text-sm text-slate-700 cursor-pointer leading-relaxed"
                  >
                    I agree to be contacted by Dr. Serena Blake regarding my inquiry. I understand that this 
                    contact may be via phone, email, or text message. *
                  </label>
                </div>
                {errors.agreeToContact && (
                  <p className="text-red-500 text-sm mt-1">{errors.agreeToContact}</p>
                )}
              </div>
              
              <Button 
                type="submit" 
                size="lg" 
                className="w-full bg-sage-600 hover:bg-sage-700 text-white py-3 text-lg font-medium"
              >
                Send Message
              </Button>
            </form>
          )}
        </div>
      </section>
    </main>
  );
}